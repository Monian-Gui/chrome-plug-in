/**
 * FE-Helper ContentScripts
 * @author zhaoxianlie@baidu.com
 */
window.onload = function(){
    document.getElementById('btnInstallExtension').style.display = 'none';
};